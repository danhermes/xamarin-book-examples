﻿using System;
using Android.App;
using Android.OS;

namespace DanHermesSamples
{
	[Activity (Label = "DanHermesSamples", Icon = "@drawable/icon")]
	public class SampleFragmentActivity : Activity
	{
		public SampleFragmentActivity ()
		{
			//Intent.Extras.GetBoolean("");
		}

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.SampleFragment);
			Title = "test";
			ActionBar.SetDisplayHomeAsUpEnabled (true);
		}
	}
}
	